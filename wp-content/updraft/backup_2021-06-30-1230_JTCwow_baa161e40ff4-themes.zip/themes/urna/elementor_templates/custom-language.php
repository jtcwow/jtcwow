<?php 
/**
 * Templates Name: Elementor
 * Widget: Custom Language
 */
    
?>
<div <?php echo trim($this->get_render_attribute_string('wrapper')); ?>>
    <?php $this->urna_custom_language(); ?>
</div>