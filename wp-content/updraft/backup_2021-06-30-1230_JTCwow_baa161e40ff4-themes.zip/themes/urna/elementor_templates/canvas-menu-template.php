<?php 
/**
 * Templates Name: Elementor
 * Widget: Canvas Menu
 */
?>
<div <?php echo trim($this->get_render_attribute_string('wrapper')); ?>>
    <?php $this->render_canvas_menu(); ?>
</div>
    