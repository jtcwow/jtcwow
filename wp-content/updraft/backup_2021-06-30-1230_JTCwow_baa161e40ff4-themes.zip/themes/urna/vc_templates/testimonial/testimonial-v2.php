<?php
	$image_id 		= isset($image_id) ? $image_id : get_post_thumbnail_id(get_the_ID());
	$name	  		= isset($testimonial_name) ? $testimonial_name : get_the_title();
	$job	  		= isset($job) ? $job : get_post_meta( get_the_ID(), 'tbay_testimonial_job', true );
	$description	= isset($description) ? $description : get_the_excerpt();
?>
<div class="testimonials-body">
	<div class="testimonials-profile"> 
	  	<div class="wrapper-avatar">
	     	<div class=" testimonial-avatar tbay-image-loaded">
			 	<?php if( !empty($image_id) ) : ?>
					<?php echo urna_tbay_get_attachment_image_loaded($image_id, 'full'); ?>
				 <?php elseif( !empty($image_url) ) : ?>
					<?php urna_tbay_src_image_loaded($image_url);  ?>
				 <?php endif; ?>
	     	</div>
	  	</div> 
	</div> 
	<div class="testimonial-meta">
		<span class="name-client"><?php echo trim($name); ?></span>
		<span class="job"><?php echo trim($job); ?></span>
		<div class="description">
			<?php echo trim($description); ?>
		</div>
	</div>
</div>